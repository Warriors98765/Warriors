const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors'); // Import the cors middleware

const app = express();
const port = 8000;

// Middleware setup
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors()); // Enable CORS for all routes

// Serve static files (including styles.css)
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.route('/')
    .get((req, res) => {
        res.sendFile(path.join(__dirname, 'login.html'));
    })
    .post((req, res) => {
        const username = req.body.username;
        const password = req.body.password;

        // Check credentials (replace with your secure authentication logic)
        if (username === 'mahesh' && password === '12345') {
            // Redirect to the home page upon successful login
            //res.redirect('C:\Users\neetu\OneDrive\Desktop\projects\LMS\home.html');  // Assuming 'home' is another route or path
            res.status(200).send(); // Send a response to the client
        } else {
            res.status(401).send('Invalid username/password combination'); // Send an error response
        }

    });

// Serve the home page
app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'home.html'));
});

// Corrected route for styles.css
app.get('/styles.css', (req, res) => {
    res.sendFile(path.join(__dirname, 'style.css'));
});