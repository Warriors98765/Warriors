// Access webcam
navigator.mediaDevices.getUserMedia({ video: true })
    .then((stream) => {
        const webcam = document.getElementById('webcam');
        webcam.srcObject = stream;
    })
    .catch((error) => {
        console.error('Error accessing webcam:', error);
    });

// Move shirt based on mouse position
document.addEventListener('mousemove', (e) => {
    const shirt = document.getElementById('shirt');
    shirt.style.top = e.clientY + 'px';
    shirt.style.left = e.clientX  +  'px';
});

function tryOn() {
    // Replace the product image source with a virtual try-on image
    document.getElementById("product-image").src = "virtual-try-on-image.jpg";
}